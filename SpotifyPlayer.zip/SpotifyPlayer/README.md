ESP32 Spotify Remote Player + Access Token Generator
====================================================

This project allows you to control Spotify playback (play, pause, next, previous) 
and display the currently playing track using an ESP32, a rotary encoder, and a 
TFT screen. A Python script is also included to generate the required access token 
using Spotify’s Authorization Code Flow.

----------------------------------------------------

FEATURES
--------

ESP32 Spotify Controller:
- Connects to Wi-Fi and Spotify Web API
- Controls playback via rotary encoder:
  - Rotate → skip track (next/previous)
  - Press → toggle play/pause
- Displays current track and artist on TFT screen

Python Token Generator:
- Generates Spotify access_token and refresh_token
- Easy copy-paste for use in Arduino code

----------------------------------------------------

HARDWARE REQUIREMENTS
----------------------

- ESP32 Dev Board
- TFT Display (e.g., ILI9341 SPI-based)
- Rotary Encoder (CLK, DT, SW)
- Micro USB cable

----------------------------------------------------

SOFTWARE REQUIREMENTS
----------------------

Arduino:
- Libraries: WiFi.h, HTTPClient.h, ArduinoJson.h, TFT_eSPI.h, Encoder.h

Python:
- Python 3.6+
- requests module (install via `pip install requests`)

----------------------------------------------------

SPOTIFY ACCESS TOKEN (Python Script)
-------------------------------------

1. Create an app on Spotify Developer Dashboard:
   https://developer.spotify.com/dashboard

2. Note your Client ID and Secret

3. Set a Redirect URI to:
   http://localhost:8888/callback

4. Edit `get_spotify_token.py` and replace:

   client_id = 'YOUR_CLIENT_ID'
   client_secret = 'YOUR_CLIENT_SECRET'
   redirect_uri = 'http://localhost:8888/callback'

5. Run the script:
   python get_spotify_token.py

6. Authorize in browser, copy the code from the redirect URL

7. Paste the code in the terminal → get your access_token

8. Copy the access_token into your ESP32 Arduino sketch:
   String access_token = "PASTE_HERE";

----------------------------------------------------

SCOPES REQUESTED
----------------

- user-read-playback-state
- user-modify-playback-state

These let your ESP32 read and control playback.

----------------------------------------------------

ROTARY ENCODER TO ESP32 PINOUT
-------------------------------

| Rotary Encoder | ESP32 GPIO |
|----------------|------------|
| CLK            | 17         |
| DT             | 18         |
| SW             | 19         |

Configure your TFT_eSPI User_Setup.h accordingly.

----------------------------------------------------

USING THE ESP32 SKETCH
-----------------------

1. Open the Arduino sketch
2. Fill in your Wi-Fi SSID, password, and Spotify access token
3. Upload the code to your ESP32
4. Open Serial Monitor to view logs
5. Watch the track and artist name on the screen
6. Use the encoder to control playback

----------------------------------------------------

NOTES
-----

- Access tokens expire after 1 hour
- Use the Python script again or implement refresh_token logic
- Spotify must be actively playing on a device when testing

----------------------------------------------------

LICENSE
-------

MIT License Free to use and modify

