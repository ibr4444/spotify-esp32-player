import requests
import base64
import urllib.parse

# Spotify developer credentials
client_id = 'YOUR_CLIENT_ID'
client_secret = 'YOUR_CLIENT_SECRET'
redirect_uri = 'http://localhost:8888/callback'
scope = 'user-read-playback-state user-modify-playback-state'

# Step 1: Get authorization code
auth_url = 'https://accounts.spotify.com/authorize'
params = {
    'client_id': client_id,
    'response_type': 'code',
    'redirect_uri': redirect_uri,
    'scope': scope
}
print("Go to the following URL and authorize the app:")
print(auth_url + '?' + urllib.parse.urlencode(params))

# Step 2: After user authorizes, they will be redirected with a URL containing ?code=
auth_code = input('\nPaste the authorization code here: ')

# Step 3: Exchange authorization code for access token
token_url = 'https://accounts.spotify.com/api/token'
auth_str = f'{client_id}:{client_secret}'
b64_auth_str = base64.b64encode(auth_str.encode()).decode()

headers = {
    'Authorization': f'Basic {b64_auth_str}',
    'Content-Type': 'application/x-www-form-urlencoded'
}

data = {
    'grant_type': 'authorization_code',
    'code': auth_code,
    'redirect_uri': redirect_uri
}

response = requests.post(token_url, headers=headers, data=data)
tokens = response.json()

print("\n Access Token:")
print(tokens['access_token'])

print("\n Refresh Token (use to get new access tokens):")
print(tokens['refresh_token'])
